"""
find_demo_corridors.py — one-off tool, not part of the app.
Scans every corridor x every intervention to find combos with the biggest,
most demo-worthy health-score swings. Run this once, hand the shortlist to
Member 4 (pitch/demo owner).
"""

import data_prep

results = []
for corridor_id, name in data_prep.corridor_list():
    for intervention in data_prep.INTERVENTIONS:
        sim = data_prep.simulate_impact(corridor_id, intervention)
        results.append({
            "corridor_id": corridor_id,
            "name": name,
            "intervention": intervention,
            "before": sim["before_score"],
            "after": sim["after_score"],
            "delta": sim["delta"],
        })

results.sort(key=lambda r: abs(r["delta"]), reverse=True)

print(f"{'Corridor':<45} {'Intervention':<22} {'Before':>7} {'After':>7} {'Delta':>7}")
print("-" * 95)
for r in results[:20]:
    print(f"{r['name']:<45} {r['intervention']:<22} {r['before']:>7} {r['after']:>7} {r['delta']:>+7}")

print()
print("Suggested demo picks (one weak/critical, one moderate, one strong-with-a-gap):")
weak = [r for r in results if r["before"] <= 60]
moderate = [r for r in results if 60 < r["before"] <= 80]
strong = [r for r in results if r["before"] > 80]

for label, bucket in [("Weak/Critical start", weak), ("Moderate start", moderate), ("Strong start", strong)]:
    bucket.sort(key=lambda r: abs(r["delta"]), reverse=True)
    if bucket:
        top = bucket[0]
        print(f"  {label}: {top['name']} - {top['intervention']} ({top['before']} -> {top['after']}, {top['delta']:+d})")
